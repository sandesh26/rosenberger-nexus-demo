
import { AppShell } from '@/components/layout/app-shell';

export default function UserAccessLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <AppShell>{children}</AppShell>;
}
