
"use client";

import React from "react";
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { UserCheck } from "lucide-react";

type UserListItem = { id: string; name: string | null; email: string | null; role?: string | null };

type AppAccess = {
  auditSystem: boolean;
  ecm: boolean;
  capitalExpenseRequestTracker: boolean;
};

export default function UserAccessPage() {
  const [users, setUsers] = React.useState<UserListItem[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [userAccess, setUserAccess] = React.useState<Record<string, AppAccess>>({});
  const [search, setSearch] = React.useState('');
  const [page, setPage] = React.useState(1);
  const [pageSize, setPageSize] = React.useState(10);

  React.useEffect(() => {
    let mounted = true;
    async function loadUsers() {
      try {
        const res = await fetch('/api/users', { cache: 'no-store', credentials: 'include' });
        if (!res.ok) {
          setUsers([]);
          setLoading(false);
          return;
        }
        const body = await res.json();
        const fetched: UserListItem[] = (body?.users || []).map((u: any) => ({ id: u.id, name: u.name ?? u.email ?? 'User', email: u.email ?? null, role: u.role ?? null }));
        if (!mounted) return;
        setUsers(fetched);

        // Initialize access map for fetched users (try loading persisted values)
        const accessMap: Record<string, AppAccess> = {};
        fetched.forEach((user) => {
          accessMap[user.id] = {
            auditSystem: user.role === 'ADMIN' || user.role === 'SUPER_ADMIN',
            ecm: false,
            capitalExpenseRequestTracker: false,
          };
        });

        // attempt to load persisted AppAccess records
        try {
          const resA = await fetch('/api/app-access', { cache: 'no-store', credentials: 'include' });
          if (resA.ok) {
            const bodyA = await resA.json();
            const accesses = bodyA?.accesses || [];
            accesses.forEach((a: any) => {
              const uid = String(a.userId);
              accessMap[uid] = {
                auditSystem: !!a.auditSystem,
                ecm: !!a.ecm,
                capitalExpenseRequestTracker: !!a.capitalExpenseRequestTracker,
              };
            });
          }
        } catch (err) {
          console.warn('[user-access] failed to load persisted app access', err);
        }

        setUserAccess(accessMap);
      } catch (err) {
        console.error('[user-access] Failed to load users', err);
        setUsers([]);
      } finally {
        if (mounted) setLoading(false);
      }
    }
    loadUsers();
    return () => { mounted = false; };
  }, []);

  const handleAccessChange = async (userId: string, app: keyof AppAccess, checked: boolean) => {
    // Optimistic update
    setUserAccess(prev => ({
      ...prev,
      [userId]: {
        ...prev[userId],
        [app]: checked,
      },
    }));

    try {
      const payload = { userId: Number(userId), access: { [app]: checked } };
      const res = await fetch('/api/app-access', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        console.error('[user-access] failed to persist access change', await res.text());
        // revert optimistic update on failure by toggling back
        setUserAccess(prev => ({
          ...prev,
          [userId]: {
            ...prev[userId],
            [app]: !checked,
          },
        }));
      }
    } catch (err) {
      console.error('[user-access] network error persisting access change', err);
      setUserAccess(prev => ({
        ...prev,
        [userId]: {
          ...prev[userId],
          [app]: !checked,
        },
      }));
    }
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center gap-4">
        <UserCheck className="h-6 w-6" />
        <h1 className="text-2xl font-semibold tracking-tight">User Access Management</h1>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Application Access</CardTitle>
          <CardDescription>
            Manage which applications each user has access to.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="text-sm text-slate-700">Show</div>
              <div className="w-18">
                <Select value={String(pageSize)} onValueChange={(v) => { setPageSize(Number(v)); setPage(1); }}>
                  <SelectTrigger className="rounded-xl">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="rounded-xl">
                    <SelectItem value="10">10</SelectItem>
                    <SelectItem value="25">25</SelectItem>
                    <SelectItem value="50">50</SelectItem>
                    <SelectItem value="100">100</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="text-sm text-slate-700">entries</div>
            </div>
            <div className="w-full max-w-sm">
              <Input
                placeholder="Search by name or email"
                value={search}
                onChange={(e: any) => { setSearch(e.target.value); setPage(1); }}
              />
            </div>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User ID</TableHead>
                <TableHead>User Name</TableHead>
                <TableHead className="text-center">Audit System</TableHead>
                <TableHead className="text-center">Engineering Change Management</TableHead>
                <TableHead className="text-center">Capital Expense Request Tracker</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center">Loading users…</TableCell>
                </TableRow>
              ) : users.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center">No users found</TableCell>
                </TableRow>
              ) : (
                // filter + paginate
                (() => {
                  const q = search.trim().toLowerCase();
                  const filtered = q ? users.filter(u => (u.name || '').toLowerCase().includes(q) || (u.email || '').toLowerCase().includes(q)) : users;
                  const total = filtered.length;
                  const totalPages = Math.max(1, Math.ceil(total / pageSize));
                  const currentPage = Math.min(Math.max(1, page), totalPages);
                  const start = (currentPage - 1) * pageSize;
                  const pageItems = filtered.slice(start, start + pageSize);

                  return (
                    <>
                      {pageItems.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell>{user.id}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-3 font-medium">
                         <Avatar className="h-9 w-9">
                          <AvatarFallback>{String(user.name).split(' ').map((n) => n[0]).join('')}</AvatarFallback>
                        </Avatar>
                        {user.name}
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      <Switch
                        checked={userAccess[user.id]?.auditSystem}
                        onCheckedChange={(checked) => handleAccessChange(user.id, 'auditSystem', checked)}
                      />
                    </TableCell>
                    <TableCell className="text-center">
                      <Switch
                        checked={userAccess[user.id]?.ecm}
                        onCheckedChange={(checked) => handleAccessChange(user.id, 'ecm', checked)}
                      />
                    </TableCell>
                    <TableCell className="text-center">
                      <Switch
                        checked={userAccess[user.id]?.capitalExpenseRequestTracker}
                        onCheckedChange={(checked) => handleAccessChange(user.id, 'capitalExpenseRequestTracker', checked)}
                      />
                    </TableCell>
                  </TableRow>
                      ))}

                      {/* Pagination controls */}
                      <TableRow>
                        <TableCell colSpan={5}>
                          <div className="flex items-center justify-between">
                            <div className="text-sm text-slate-600">Showing {pageItems.length} of {total} users</div>
                            <div className="flex items-center gap-2">
                              <Button size="sm" variant="outline" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={currentPage <= 1}>Prev</Button>
                              <div className="text-sm">Page {currentPage} / {totalPages}</div>
                              <Button size="sm" variant="outline" onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={currentPage >= totalPages}>Next</Button>
                            </div>
                          </div>
                        </TableCell>
                      </TableRow>
                    </>
                  );
                })()
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
