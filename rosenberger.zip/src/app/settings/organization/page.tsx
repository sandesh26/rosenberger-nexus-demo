import React from 'react';
import prisma from '@/lib/prisma';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import DepartmentsAdmin from '@/components/departments/DepartmentsAdmin';
import AddDepartmentDialog from '@/components/departments/AddDepartmentDialog';
import AreasAdmin from '@/components/areas/AreasAdmin';
import AddAreaDialog from '@/components/areas/AddAreaDialog';
import ZonesAdmin from '@/components/zones/ZonesAdmin';
import AddZoneDialog from '@/components/zones/AddZoneDialog';
import BusinessUnitsAdmin from '@/components/businessUnits/BusinessUnitsAdmin';
import AddBusinessUnitDialog from '@/components/businessUnits/AddBusinessUnitDialog';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';

export default async function OrganizationIndex() {
  const businessUnits = await prisma.businessUnit.findMany({ orderBy: { id: 'asc' } });
  const departments = await prisma.department.findMany({ include: { deptHead: true }, orderBy: { id: 'asc' } });
  const users = await prisma.user.findMany({ select: { id: true, name: true } });
  const areas = await prisma.area.findMany({ orderBy: { id: 'asc' } });
  const zones = await prisma.zone.findMany({ include: { leader: true, area: true }, orderBy: { id: 'asc' } });

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold tracking-tight">Organization Management</h1>
      </div>
      <Card>
        <CardContent>
          <Tabs defaultValue="business-units">
            <TabsList>
                <TabsTrigger value="business-units">Business Unit</TabsTrigger>
                <TabsTrigger value="departments">Departments</TabsTrigger>
                <TabsTrigger value="areas">Areas</TabsTrigger>
                <TabsTrigger value="zones">Zones</TabsTrigger>
              </TabsList>
              <TabsContent value="business-units">
                <BusinessUnitsAdmin
                  initialBusinessUnits={businessUnits}
                />
              </TabsContent>
              <TabsContent value="departments">
              <DepartmentsAdmin 
                initialDepartments={departments} 
                initialUsers={users}
                addButton={
                  <AddDepartmentDialog users={users}>
                    <Button className="flex items-center gap-2"><PlusCircle className="h-4 w-4" />Add Department</Button>
                  </AddDepartmentDialog>
                }
              />
            </TabsContent>
            <TabsContent value="areas">
              <AreasAdmin
                initialAreas={areas}
                initialUsers={users}
                addButton={
                  <AddAreaDialog users={users}>
                    <Button className="flex items-center gap-2"><PlusCircle className="h-4 w-4" />Add Area</Button>
                  </AddAreaDialog>
                }
              />
            </TabsContent>
            <TabsContent value="zones">
              <ZonesAdmin
                initialZones={zones}
                addButton={
                  <AddZoneDialog>
                    <Button className="flex items-center gap-2"><PlusCircle className="h-4 w-4" />Add Zone</Button>
                  </AddZoneDialog>
                }
              />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
