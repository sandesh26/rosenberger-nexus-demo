import React from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export default function ZonesPage() {
  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold tracking-tight">Zones</h1>
      </div>
      <Card>
        <CardHeader>
          <div className="w-full flex items-start justify-between">
            <div />
            <div className="pt-2">
              <Button disabled variant="ghost">Add Zone</Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-sm text-muted-foreground">Zones management will be added here.</div>
        </CardContent>
      </Card>
    </div>
  );
}
