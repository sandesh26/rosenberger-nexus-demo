import React from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import prisma from '@/lib/prisma';
import DepartmentsAdmin from '@/components/departments/DepartmentsAdmin';
import AddDepartmentDialog from '@/components/departments/AddDepartmentDialog';
import { Button } from '@/components/ui/button';

export default async function DepartmentsPage() {
  const departments = await prisma.department.findMany({ include: { deptHead: true }, orderBy: { id: 'asc' } });
  const users = await prisma.user.findMany({ select: { id: true, name: true } });

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold tracking-tight">Departments</h1>
      </div>
      <Card>
        <CardHeader>
          <div className="w-full flex items-start justify-between">
            <div />
            <div className="pt-2">
              <AddDepartmentDialog users={users}>
                <Button>Add Department</Button>
              </AddDepartmentDialog>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <DepartmentsAdmin initialUsers={users} initialDepartments={departments} />
        </CardContent>
      </Card>
    </div>
  );
}
