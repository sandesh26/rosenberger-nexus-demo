"use client";

import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import PasswordInput from "@/components/ui/password-input";

export default function SettingsPage() {
  const [passwordLoading, setPasswordLoading] = useState(false);
  const [passwordStatus, setPasswordStatus] = useState<string | null>(null);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  async function handlePasswordUpdate(e: React.FormEvent) {
    e.preventDefault();
    
    // Trim whitespace
    const trimmedNew = newPassword.trim();
    const trimmedConfirm = confirmPassword.trim();
    
    if (!trimmedNew || !trimmedConfirm) {
      setPasswordStatus("New password and confirmation are required");
      return;
    }
    if (trimmedNew !== trimmedConfirm) {
      setPasswordStatus("New passwords do not match");
      return;
    }
    if (trimmedNew.length < 6) {
      setPasswordStatus("Password must be at least 6 characters");
      return;
    }

    setPasswordLoading(true);
    setPasswordStatus(null);
    try {
      console.log('[settings] Password update request:', { newPassword: trimmedNew.length, confirmPassword: trimmedConfirm.length });
      const res = await fetch('/api/users/reset-password-admin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ 
          newPassword: trimmedNew
        }),
      });

      const body = await res.json();
      console.log('[settings] Password update response:', { status: res.status, ok: res.ok, body });
      if (!res.ok) {
        setPasswordStatus(body?.error || 'Failed to update password');
      } else {
        setPasswordStatus(body?.message || 'Password updated successfully');
        setNewPassword("");
        setConfirmPassword("");
        setTimeout(() => setPasswordStatus(null), 3000);
      }
    } catch (err) {
      console.error('[settings] Password update error:', err);
      setPasswordStatus("Network error");
    } finally {
      setPasswordLoading(false);
    }
  }

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
        <p className="text-slate-500 mt-1">Manage your security and account settings</p>
      </div>

      {/* Change Password Card */}
      <Card>
        <CardHeader>
          <CardTitle className="text-xl flex items-center gap-2">
            <Lock className="h-5 w-5" />
            Change Password
          </CardTitle>
          <CardDescription>Update your password to keep your account secure</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handlePasswordUpdate} className="space-y-4">
            <div>
              <PasswordInput
                label="New Password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Enter your new password"
              />
            </div>

            <div>
              <PasswordInput
                label="Confirm New Password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Confirm your new password"
              />
            </div>

            {passwordStatus && (
              <p className={`text-sm ${passwordStatus.includes("successfully") ? "text-green-600 font-semibold" : "text-red-600 font-semibold"}`}>
                {passwordStatus}
              </p>
            )}

            <Button 
              disabled={passwordLoading} 
              className="w-full bg-red-600 hover:bg-red-700 text-white"
            >
              {passwordLoading ? "Updating…" : "Update Password"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
