import { redirect } from 'next/navigation'

export default function DeprecatedDepartmentsIndex() {
  // Route moved to /settings/organization/departments
  redirect('/settings/organization/departments')
}
