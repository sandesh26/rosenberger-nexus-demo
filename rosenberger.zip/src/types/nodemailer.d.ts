// Minimal ambient declaration so TypeScript won't error when nodemailer is dynamically imported
// during runtime in environments where the package isn't installed.
declare module 'nodemailer' {
  const nodemailer: any;
  export default nodemailer;
  export function createTransport(config?: any): any;
}
